# 加载必要的库
library(raster)
library(lubridate)

# 设置包含TIF文件的目录路径（请修改为您的实际路径）
tif_dir <- "E:/papering/forest_mortality/Environment/Vagetation/VOD/image/" 

# 设置输出结果的目录（请修改为您的实际路径）
output_dir <- "E:/papering/forest_mortality/Environment/Vagetation/VOD/yearly/" 

# 如果输出目录不存在，则创建它
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出目录中所有的TIF文件
tif_files <- list.files(tif_dir, pattern = "GLAB_VOD_\\d{4}_\\d{8}\\.tif$", full.names = TRUE)

# 创建一个数据框来存储文件信息
file_info <- data.frame(
  file_path = tif_files,
  file_name = basename(tif_files),
  stringsAsFactors = FALSE
)

# 从文件名中提取年份和日期
file_info$year <- as.numeric(gsub(".*GLAB_VOD_(\\d{4})_.*", "\\1", file_info$file_name))
file_info$date_str <- gsub(".*GLAB_VOD_\\d{4}_(\\d{8}).*", "\\1", file_info$file_name)
file_info$date <- as.Date(file_info$date_str, format = "%Y%m%d")
file_info$month <- month(file_info$date)

# 筛选出生长季(5-9月)的文件
growing_season_files <- file_info[file_info$month >= 5 & file_info$month <= 9, ]

# 按年份分组处理
years <- unique(growing_season_files$year)

for (year in years) {
  # 获取当前年份生长季的所有文件
  current_year_files <- growing_season_files$file_path[growing_season_files$year == year]
  
  if (length(current_year_files) > 0) {
    cat("处理", year, "年的生长季数据，共", length(current_year_files), "个文件\n")
    
    # 读取所有栅格
    raster_list <- lapply(current_year_files, raster)
    
    # 确保所有栅格有相同的范围和分辨率
    if (length(raster_list) > 1) {
      # 检查所有栅格是否可以堆叠
      can_stack <- TRUE
      for (i in 2:length(raster_list)) {
        if (!compareRaster(raster_list[[1]], raster_list[[i]], stopiffalse = FALSE)) {
          can_stack <- FALSE
          break
        }
      }
      
      if (can_stack) {
        # 将所有栅格堆叠为一个栅格集
        raster_stack <- stack(raster_list)
        
        # 计算平均值
        mean_raster <- calc(raster_stack, fun = mean, na.rm = TRUE)
        
        # 定义输出文件名
        output_file <- file.path(output_dir, paste0("GLAB_VOD_", year, ".tif"))
        
        # 保存结果
        writeRaster(mean_raster, output_file, format = "GTiff", overwrite = TRUE)
        
        cat("  已保存", basename(output_file), "\n")
      } else {
        cat("  警告: 年份", year, "的栅格范围或分辨率不一致，无法计算平均值\n")
      }
    } else if (length(raster_list) == 1) {
      # 只有一个文件，直接复制
      output_file <- file.path(output_dir, paste0("GLAB_VOD_", year, ".tif"))
      file.copy(current_year_files[1], output_file, overwrite = TRUE)
      cat("  年份", year, "只有一个生长季文件，已复制为", basename(output_file), "\n")
    }
  } else {
    cat("年份", year, "没有生长季数据\n")
  }
}

cat("处理完成！\n")
