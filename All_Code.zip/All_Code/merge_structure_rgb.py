# -*- coding: utf-8 -*-
"""
将 LAD、VCI、CRR 三个单波段栅格合并为一个三波段 GeoTIFF。

波段顺序:
1 = LAD
2 = VCI
3 = CRR
"""

from pathlib import Path

from osgeo import gdal
import numpy as np


INPUT_DIR = Path(
    r"E:\papering\boreal forest structure\1StructurePattern\Raster\Mapping_structure\Sturcture_RGB"
)
LAD_PATH = INPUT_DIR / "Forest_Lad_2023_11.tif"
VCI_PATH = INPUT_DIR / "Forest_VCI_2023_11.tif"
CRR_PATH = INPUT_DIR / "Forest_CRR_2023_11.tif"
OUTPUT_PATH = INPUT_DIR / "Forest_Structure_RGB_2023_11_normalized.tif"


def ensure_exists(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"未找到输入文件: {path}")


def open_dataset(path: Path):
    ds = gdal.Open(str(path), gdal.GA_ReadOnly)
    if ds is None:
        raise RuntimeError(f"无法打开栅格: {path}")
    return ds


def assert_same_grid(reference_ds, other_ds, other_name: str) -> None:
    failed = []

    if reference_ds.RasterXSize != other_ds.RasterXSize:
        failed.append("width")
    if reference_ds.RasterYSize != other_ds.RasterYSize:
        failed.append("height")
    if reference_ds.GetGeoTransform() != other_ds.GetGeoTransform():
        failed.append("geotransform")
    if reference_ds.GetProjection() != other_ds.GetProjection():
        failed.append("projection")

    if failed:
        raise ValueError(
            f"{other_name} 与参考栅格不一致，存在以下问题: {', '.join(failed)}"
        )


def compute_valid_min_max(src_band, block_size: int) -> tuple[float, float]:
    x_size = src_band.XSize
    y_size = src_band.YSize
    nodata = src_band.GetNoDataValue()

    valid_min = None
    valid_max = None

    for y_off in range(0, y_size, block_size):
        rows = min(block_size, y_size - y_off)
        for x_off in range(0, x_size, block_size):
            cols = min(block_size, x_size - x_off)
            data = src_band.ReadAsArray(x_off, y_off, cols, rows)

            if nodata is None:
                valid = np.isfinite(data)
            else:
                valid = np.isfinite(data) & (data != nodata)

            if not np.any(valid):
                continue

            block_min = float(data[valid].min())
            block_max = float(data[valid].max())

            if valid_min is None or block_min < valid_min:
                valid_min = block_min
            if valid_max is None or block_max > valid_max:
                valid_max = block_max

    if valid_min is None or valid_max is None:
        raise ValueError("未找到有效像元，无法归一化。")

    return valid_min, valid_max


def normalize_block(data, nodata, valid_min: float, valid_max: float):
    if nodata is None:
        valid = np.isfinite(data)
    else:
        valid = np.isfinite(data) & (data != nodata)

    out = np.full(data.shape, nodata if nodata is not None else np.nan, dtype=np.float32)

    if valid_max == valid_min:
        out[valid] = 0.0
        return out

    out[valid] = (data[valid] - valid_min) / (valid_max - valid_min)
    return out


def main() -> None:
    gdal.UseExceptions()

    for path in (LAD_PATH, VCI_PATH, CRR_PATH):
        ensure_exists(path)

    lad_ds = open_dataset(LAD_PATH)
    vci_ds = open_dataset(VCI_PATH)
    crr_ds = open_dataset(CRR_PATH)

    try:
        assert_same_grid(lad_ds, vci_ds, "VCI")
        assert_same_grid(lad_ds, crr_ds, "CRR")

        driver = gdal.GetDriverByName("GTiff")
        output_ds = driver.Create(
            str(OUTPUT_PATH),
            lad_ds.RasterXSize,
            lad_ds.RasterYSize,
            3,
            gdal.GDT_Float32,
            options=["COMPRESS=LZW"],
        )
        if output_ds is None:
            raise RuntimeError(f"无法创建输出文件: {OUTPUT_PATH}")

        output_ds.SetGeoTransform(lad_ds.GetGeoTransform())
        output_ds.SetProjection(lad_ds.GetProjection())

        band_info = [
            (lad_ds.GetRasterBand(1), "LAD", 1),
            (vci_ds.GetRasterBand(1), "VCI", 2),
            (crr_ds.GetRasterBand(1), "CRR", 3),
        ]

        block_size = 1024
        x_size = lad_ds.RasterXSize
        y_size = lad_ds.RasterYSize
        band_ranges = []

        for src_band, band_name, _ in band_info:
            valid_min, valid_max = compute_valid_min_max(src_band, block_size)
            band_ranges.append((valid_min, valid_max))
            print(f"{band_name}: min={valid_min:.6f}, max={valid_max:.6f}")

        for (src_band, band_name, out_index), (valid_min, valid_max) in zip(
            band_info, band_ranges
        ):
            out_band = output_ds.GetRasterBand(out_index)
            out_band.SetDescription(band_name)

            nodata = src_band.GetNoDataValue()
            if nodata is not None:
                out_band.SetNoDataValue(nodata)

            for y_off in range(0, y_size, block_size):
                rows = min(block_size, y_size - y_off)
                for x_off in range(0, x_size, block_size):
                    cols = min(block_size, x_size - x_off)
                    data = src_band.ReadAsArray(x_off, y_off, cols, rows)
                    normalized = normalize_block(data, nodata, valid_min, valid_max)
                    out_band.WriteArray(normalized, x_off, y_off)

            out_band.FlushCache()

        output_ds.FlushCache()
        output_ds = None

    finally:
        lad_ds = None
        vci_ds = None
        crr_ds = None

    print(f"output={OUTPUT_PATH}")
    print("bands=1:LAD,2:VCI,3:CRR")


if __name__ == "__main__":
    main()
