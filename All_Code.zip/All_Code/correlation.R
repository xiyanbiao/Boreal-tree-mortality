print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig2/for_r/")

library(Hmisc)
library(corrplot)
# 数据读取与预处理
data <- read.csv("E:/papering/forest_mortality/Plot/fig2/for_PSEM/target_LLTB_deleted2.csv", header = TRUE)
head(data)

target_vars <- data[, c("LLTB", names(data)[2:which(names(data) == "KVOD_T")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))

# 相关系数计算
cor_matrix <- rcorr(as.matrix(target_vars), type = "pearson")

# 构建结果数据框
results <- data.frame(
  Variable = colnames(target_vars)[-1],
  Correlation = cor_matrix$r["LLTB", -1],
  P_value = cor_matrix$P["LLTB", -1],
  N = cor_matrix$n["LLTB", -1]
)

# 显著性标记
results$Significance <- cut(
  results$P_value,
  breaks = c(0, 0.001, 0.01, 0.05, 0.1, 1),
  labels = c("***", "**", "*", ".", " "),
  include.lowest = TRUE
)

# 置信区间计算
results$CI_lower <- NA
results$CI_upper <- NA
for (i in 1:nrow(results)) {
  if (results$N[i] > 3) {
    r <- results$Correlation[i]
    n <- results$N[i]
    
    # Fisher Z变换
    z <- 0.5 * log((1 + r)/(1 - r))
    se <- 1/sqrt(n - 3)
    ci_z <- z + c(-1, 1) * 1.96 * se
    
    # 逆变换
    ci_r <- (exp(2 * ci_z) - 1)/(exp(2 * ci_z) + 1)
    results$CI_lower[i] <- ci_r[1]
    results$CI_upper[i] <- ci_r[2]
  }
}

# 多重检验校正
results$Adj_P_value <- p.adjust(results$P_value, method = "bonferroni")

# 结果格式化
formatted_results <- transform(
  results,
  Correlation = round(Correlation, 3),
  CI_95 = sprintf("[%.3f, %.3f]", CI_lower, CI_upper),
  P_value = format.pval(P_value, digits = 3),
  Adj_P_value = format.pval(Adj_P_value, digits = 3)
)[, c("Variable", "Correlation", "CI_95", "P_value", "Adj_P_value", "Significance", "N")]

print(formatted_results, row.names = FALSE)

# 结果导出
write.csv(formatted_results, "correlation_LLTB0713.csv", row.names = FALSE)
