print(getwd())
setwd("E:/papering/forest_mortality/样地数据统计")

library(lme4)
library(lmerTest)  
library(car)
library(corrplot)
library(ggcorrplot)
library(ggplot2)

data <- read.csv("E:/papering/forest_mortality/样地数据统计/climate_LT.csv", header = TRUE)
head(data)

################## 气候趋势变量
independent_vars <- data[, c("ΔEHD", "ΔLSF", "ΔMAT", "ΔPRE", "ΔVPD", "ΔFFD", "ΔGDD", "ΔWIND", "ΔSPEImin", "ΔMWT", "ΔSCD")]
str(independent_vars)
# 计算相关系数矩阵
correlation_matrix <- cor(independent_vars, use = "complete.obs")
# 查看相关系数矩阵
print(round(correlation_matrix, 2))
# 创建相关性图
png("correlation_matrix.png", width = 900, height = 900, res = 200)
corrplot(correlation_matrix, method = "color", type = "upper", 
         tl.col = "black", tl.srt = 45, tl.cex = 0.6,
         addCoef.col = "black", number.cex = 0.6,
         mar = c(0,0,1,0))
dev.off()

# VIF分析
# 使用car包的vif函数
# 首先建立一个线性模型
model <- lm(D_differ_s ~ ΔEHD + ΔLSF + ΔMAT + ΔPRE + ΔVPD + ΔFFD + ΔGDD + ΔWIND + ΔSPEImin + ΔMWT + ΔSCD, data = data)
# 计算VIF
vif_values <- vif(model)
print(vif_values)

# 创建VIF结果的数据框，便于查看
vif_results <- data.frame(
  Variable = names(vif_values),
  VIF = vif_values
)
vif_results <- vif_results[order(-vif_results$VIF),]  # 按VIF降序排列
print(vif_results)

# 可视化VIF值
ggplot(vif_results, aes(x = reorder(Variable, VIF), y = VIF)) +
  geom_bar(stat = "identity", fill = "steelblue",width = 0.6) +
  # geom_hline(yintercept = 5, linetype = "dashed", color = "red", size = 1) +
  # geom_hline(yintercept = 10, linetype = "dashed", color = "darkred", size = 1) +
  scale_y_continuous(expand = c(0,0),limits = c(0, 3),breaks = seq(0,2.9,1)) +
  coord_flip() +
  labs(x = "Climate trend variables", y = "VIF Value") +
# annotate("text", x = 1, y = 5.5, label = "VIF = 5", color = "red") +
# annotate("text", x = 1, y = 10.5, label = "VIF = 10", color = "darkred")
  theme_linedraw(base_size = 25) +
  theme(text = element_text(size = 28), axis.text = element_text(size = 25),legend.position = "none",
        #axis.text.x = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_blank()
  )
ggsave("VIF_LT_trend.jpg", width = 8, height = 10, dpi = 300)


################## 气候均值变量
independent_vars <- data[, c("EHD", "LSF", "MAT", "PRE", "VPD", "FFD", "GDD", "WIND", "SPEImin", "MWT", "SCD")]
str(independent_vars)
# 计算相关系数矩阵
correlation_matrix <- cor(independent_vars, use = "complete.obs")
# 查看相关系数矩阵
print(round(correlation_matrix, 2))
# 创建相关性图
png("均值_corr.png", width = 900, height = 900, res = 200)
corrplot(correlation_matrix, method = "color", type = "upper", 
         tl.col = "black", tl.srt = 45, tl.cex = 0.6,
         addCoef.col = "black", number.cex = 0.6,
         mar = c(0,0,1,0))
dev.off()

# VIF分析
# 使用car包的vif函数
# 首先建立一个线性模型
model <- lm(D_differ_s ~ EHD + LSF + MAT + PRE + VPD + FFD + GDD + WIND + SPEImin + MWT + SCD, data = data)
# 计算VIF
vif_values <- vif(model)
print(vif_values)

# 创建VIF结果的数据框，便于查看
vif_results <- data.frame(
  Variable = names(vif_values),
  VIF = vif_values
)
vif_results <- vif_results[order(-vif_results$VIF),]  # 按VIF降序排列
print(vif_results)

# 可视化VIF值
ggplot(vif_results, aes(x = reorder(Variable, VIF), y = VIF)) +
  geom_bar(stat = "identity", fill = "#1c8041",width = 0.6) +
  geom_hline(yintercept = 5, linetype = "dashed", color = "red", size = 1) +
  geom_hline(yintercept = 10, linetype = "dashed", color = "darkred", size = 1) +
  scale_y_continuous(expand = c(0,0),limits = c(0, 13),breaks = seq(0,12,3)) +
  coord_flip() +
  labs(x = "Climate mean variables", y = "VIF Value") +
  annotate("text", x = 1, y = 5.5, size=10, label = "VIF = 5", color = "red") +
  annotate("text", x = 1, y = 10.5, size=10, label = "VIF = 10", color = "darkred")+
  theme_linedraw(base_size = 25) +
  theme(text = element_text(size = 28), axis.text = element_text(size = 25),legend.position = "none",
        #axis.text.x = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_blank()
  )
ggsave("VIF_LT_mean.jpg", width = 8, height = 10, dpi = 300)
