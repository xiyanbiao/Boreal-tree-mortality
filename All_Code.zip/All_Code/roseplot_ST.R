print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig1/fig1_tree_speceis/")

library(ggplot2)
library(dplyr)

############################## small tree 1D ########################################
# 读取数据
df <- read.csv("E:/papering/forest_mortality/Plot/fig1/fig1_tree_speceis/ST_1_D.csv", header = TRUE)
head(df)
# 为每个Genus指定颜色
genus_colors <- c(
  "PICE" = "#34a72d",  # 绿色
  "ABIE" = "#62a9a1",  # 青色
  "POPU" = "#96d374",  # 浅绿色
  "PINU" = "#e22e27",  # 红色
  "SALI" = "lightblue",
  "ALNU" = "darkgreen",
  "BETU" = "#7b54a8",  # 紫色
  "LARI" = "#3e8fc1",  # 蓝色
  "Others" = "darkgrey" # 浅橙色
)

ggplot(df, aes(x = Genus, y = Percent, fill = Genus)) +
  geom_col(width = 1, color = "white", size = 0.5) +    # 使用柱状图基础
  coord_polar(theta = "x", start = 0) +                 # 关键修改：极坐标映射到x轴
  scale_fill_manual(values = genus_colors) +
  theme_minimal() +  # 使用minimal主题保留轴线
  theme(
    legend.position = "none",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10),
    axis.text.y = element_blank(),  
    axis.text.x = element_text(size = 25, color = "black", angle = 0),  # 显示x轴标签
    axis.title = element_blank(),
    panel.grid.major = element_line(color = "grey", linetype = "dashed")
  )
ggsave("ST_1_D.jpg", width = 8, height = 8, dpi = 300)

############################## small tree 2D ########################################

# 读取数据
df <- read.csv("E:/papering/forest_mortality/Plot/fig1/fig1_tree_speceis/ST_2_D.csv", header = TRUE)
head(df)
# 为每个Genus指定颜色
genus_colors <- c(
  "PICE" = "#34a72d",  # 绿色8
  "ABIE" = "#62a9a1",  # 青色8
  "POPU" = "#96d374",  # 浅绿色8
  "PINU" = "#e22e27",  # 红色8
  "THUJ" = "orange",
  "ACER" = "pink",
  "BETU" = "grey",
  "ALNU" = "#ddc386",
  "Others" = "darkgrey" # 浅橙色
)

ggplot(df, aes(x = Genus, y = Percent, fill = Genus)) +
  geom_col(width = 1, color = "white", size = 0.5) +    # 使用柱状图基础
  coord_polar(theta = "x", start = 0) +                 # 关键修改：极坐标映射到x轴
  scale_fill_manual(values = genus_colors) +
  theme_minimal() +  # 使用minimal主题保留轴线
  theme(
    legend.position = "none",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10),
    axis.text.y = element_blank(),  
    axis.text.x = element_text(size = 25, color = "black", angle = 0),  # 显示x轴标签
    axis.title = element_blank(),
    panel.grid.major = element_line(color = "grey", linetype = "dashed")
  )
ggsave("ST_2_D.jpg", width = 8, height = 8, dpi = 300)


############################## large tree 2L ########################################
# 读取数据
df <- read.csv("E:/papering/forest_mortality/Plot/fig1/fig1_tree_speceis/ST_2_L.csv", header = TRUE)
head(df)
# 为每个Genus指定颜色
genus_colors <- c(
  "PICE" = "#34a72d",  # 绿色8
  "ABIE" = "#62a9a1",  # 青色8
  "POPU" = "#96d374",  # 浅绿色8
  "PINU" = "#e22e27",  # 红色8
  "BETU" = "#7b54a8",  # 紫色8
  "ACER" = "pink",
  "THUJ" = "orange",
  "ALNU" = "#ddc386",
  "Others" = "darkgrey" # 浅橙色8
)

ggplot(df, aes(x = Genus, y = Percent, fill = Genus)) +
  geom_col(width = 1, color = "white", size = 0.5) +    # 使用柱状图基础
  coord_polar(theta = "x", start = 0) +                 # 关键修改：极坐标映射到x轴
  scale_fill_manual(values = genus_colors) +
  theme_minimal() +  # 使用minimal主题保留轴线
  theme(
    legend.position = "none",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10),
    axis.text.y = element_blank(),  
    axis.text.x = element_text(size = 25, color = "black", angle = 0),  # 显示x轴标签
    axis.title = element_blank(),
    panel.grid.major = element_line(color = "grey", linetype = "dashed")
  )

ggsave("ST_2_L.jpg", width = 8, height = 8, dpi = 300)
