print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig3/small_tree/")
library(Hmisc)
library(corrplot)
library(car)
library(caret)
library(lme4)
library(lmerTest) 
library(MuMIn)
library(performance)
library(ppcor)
library(ggplot2)
library(tidyverse)
library(stats)
# 读取数据并预处理
data <- read.csv("E:/papering/forest_mortality/Plot/fig3/small_tree/ALL_ST.csv", header = TRUE)
head(data)
target_vars <- data[, c("ALG",  names(data)[which(names(data) == "MAT_T"):which(names(data) == "SOS_T")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)

# 标准化所有预测变量（不包括目标变量和时间）
scaled_vars <- !names(target_vars) %in% c("ALG")
target_vars[, scaled_vars] <- scale(target_vars[, scaled_vars])  # 标准化
head(target_vars)

# time_model <- lm(DDs ~ Year, data = target_vars)
# target_vars$DDs_residuals <- residuals(time_model)
# 
# predictors <- names(target_vars)[!names(target_vars) %in% c("DDs", "Year", "DDs_residuals")]
# total_data <- target_vars[, c("DDs_residuals", predictors)]

# 计算偏相关矩阵
pcor_result <- pcor(target_vars)

# 提取与residuals相关的偏相关系数和p值
pcor <- pcor_result$estimate["ALG", -which(colnames(pcor_result$estimate) == "ALG")]
p_values <- pcor_result$p.value["ALG", -which(colnames(pcor_result$p.value) == "ALG")]

# 创建一个数据框来存储结果
pcor_df <- data.frame(
  Variable = names(pcor),
  PartialCorr = pcor,
  P_Value = p_values
)
# 按偏相关系数绝对值排序
pcor_df <- pcor_df[order(abs(pcor_df$PartialCorr), decreasing = TRUE), ]
# 显示结果
print(pcor_df)

# 获取所有其他变量（除了residuals和MAT_T）
other_vars <- setdiff(names(target_vars), c("ALG", "MAT_T"))

# 对MAT_T进行回归，使用所有其他变量作为预测变量
mat_formula <- as.formula(paste("MAT_T ~", paste(other_vars, collapse = " + ")))
mat_model <- lm(mat_formula, data = target_vars)
mat_residuals <- residuals(mat_model)  

# 对residuals进行回归，使用所有其他变量作为预测变量
formula <- as.formula(paste("ALG ~", paste(other_vars, collapse = " + ")))
model <- lm(formula, data = target_vars)
partial_residuals <- residuals(model)

# 计算这两组残差之间的相关性
partial_cor <- cor(mat_residuals, partial_residuals)
print(paste("Partial correlation between residuals and MAT_T:", round(partial_cor, 6)))

# 创建包含三列的数据框
export_data <- data.frame(
  DDs_residuals = target_vars$ALG,
  ALG  = partial_residuals,
  MAT_partial = mat_residuals,
  MAT_original = target_vars$MAT_T,
  MAT_data = data$MAT_T
)

# 导出为CSV
write.csv(export_data, "ALGst_MAT.csv", row.names = FALSE)

# 绘制偏相关散点图
library(ggplot2)
ggplot(data.frame(x = mat_residuals, y = partial_residuals), aes(x = x, y = y)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  labs(x = "MAT (Partial)", y = "DDs_residuals (Partial)", 
       title = paste("Partial Correlation between LDTM_residuals and MAT: r =", 
                     round(partial_cor, 3))) +
  theme_minimal()
