print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig2/for_PCA")
library(Hmisc)
library(corrplot)
library(car)
library(caret)
library(lme4)
library(lmerTest) 
library(MuMIn)
library(performance)
library(ppcor)
library(ggplot2)
library(tidyverse)
library(stats)
# 读取数据并预处理
data <- read.csv("E:/papering/forest_mortality/Plot/fig2/for_PCA/target_LLTB_deleted.csv", header = TRUE)
head(data)
target_vars <- data[, c("LLTB","Time", names(data)[which(names(data) == "MAT"):which(names(data) == "LVOD_T")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)

# 标准化所有预测变量（不包括目标变量和时间）
scaled_vars <- !names(target_vars) %in% c("LLTB", "Time")
target_vars[, scaled_vars] <- scale(target_vars[, scaled_vars])  # 标准化

time_model <- lm(LLTB ~ Time, data = target_vars)
target_vars$LLTB_residuals <- residuals(time_model)

predictors <- names(target_vars)[!names(target_vars) %in% c("LLTB", "Time", "LLTB_residuals")]
total_data <- target_vars[, c("LLTB_residuals", predictors)]
head(total_data)

# 确保数据无缺失值
if(any(is.na(total_data))) {
  warning("数据中存在缺失值，可能会影响PCA结果")
}

# # 1. 干旱热胁迫指标: VPD, EHD
# drought_heat_pca <- prcomp(total_data[, c("VPD", "EHD")], scale. = TRUE)
# Drought_Heat_Stress <- drought_heat_pca$x[, 1]
# # 查看解释方差比例
# drought_heat_var <- summary(drought_heat_pca)$importance[2, 1]
# cat("干旱热胁迫PC1解释方差比例:", drought_heat_var, "\n")

# # 2. 干旱热胁迫指标趋势: VPD_T, EHD_T
# photo_trend_pca <- prcomp(total_data[, c("VPD_T", "EHD_T")], scale. = TRUE)
# Photosynthetic_Production_Trend <- photo_trend_pca$x[, 1]
# photo_trend_var <- summary(photo_trend_pca)$importance[2, 1]
# cat("光合生产力趋势PC1解释方差比例:", photo_trend_var, "\n")

# 4. 林分结构与竞争: BA, SD
stand_size_pca <- prcomp(total_data[, c("BA",  "SD")], scale. = TRUE)
Stand_Size_Competition <- stand_size_pca$x[, 1]
stand_size_var <- summary(stand_size_pca)$importance[2, 1]
cat("林分结构与竞争PC1解释方差比例:", stand_size_var, "\n")

# # 5. 光合生产力: SIF, NPP
# photo_prod_pca <- prcomp(total_data[, c("SIF", "NPP")], scale. = TRUE)
# Photosynthetic_Production <- photo_prod_pca$x[, 1]
# photo_prod_var <- summary(photo_prod_pca)$importance[2, 1]
# cat("光合生产力PC1解释方差比例:", photo_prod_var, "\n")

# 添加PC1到数据集并使用简写变量名
total_data_pca <- total_data %>%
  mutate(
    #DHS1 = Drought_Heat_Stress,           # 干旱热胁迫PC1
    #PPT1 = Photosynthetic_Production_Trend, # VPD_T和EHD_T的PC1
    SSC1 = Stand_Size_Competition,         # 林分结构与竞争PC1
    #PP1 = Photosynthetic_Production        # 光合生产力PC1
  ) %>%
  # 移除已经做过PCA的原始变量
  select(-c(BA, SD))

# 查看新数据集的前几行
head(total_data_pca)
# 计算偏相关矩阵
pcor_result <- pcor(total_data)

# 提取与SLB_D_residuals相关的偏相关系数和p值
slb_pcor <- pcor_result$estimate["LLTB_residuals", -which(colnames(pcor_result$estimate) == "LLTB_residuals")]
slb_p_values <- pcor_result$p.value["LLTB_residuals", -which(colnames(pcor_result$p.value) == "LLTB_residuals")]

# 创建一个数据框来存储结果
pcor_df <- data.frame(
  Variable = names(slb_pcor),
  PartialCorr = slb_pcor,
  P_Value = slb_p_values
)
# 按偏相关系数绝对值排序
pcor_df <- pcor_df[order(abs(pcor_df$PartialCorr), decreasing = TRUE), ]
# 显示结果
print(pcor_df)
#write.csv(pcor_df, "SDB_ppcor_results.csv")

# 标记显著的偏相关（p < 0.05）
sig_pcor <- pcor_df[pcor_df$P_Value < 0.05, ]
print("显著的偏相关系数:")
print(sig_pcor)

par(mar = c(10, 4, 4, 2) + 0.1)  # 增加底部边距以容纳变量名
barplot(pcor_df$PartialCorr,
        names.arg = pcor_df$Variable,
        las = 2,  # 垂直显示变量名
        cex.names = 0.7,  # 调整变量名大小
        main = "Partial Correlation with SLB_D_residuals",
        ylab = "Partial Correlation Coefficient",
        col = ifelse(pcor_df$P_Value < 0.05, "darkblue", "lightblue"))
abline(h = 0, col = "red", lwd = 2)  # 添加零线

