print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig2")
library(gbm)
library(dismo)
library(caret)
library(pdp)

# 读取数据并预处理
data <- read.csv("E:/papering/forest_mortality/Plot/fig2/for_GLMM/target_LLB.csv", header = TRUE)
target_vars <- data[, c("LLB_D", names(data)[5:which(names(data) == "Time")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)
# 标准化所有预测变量（不包括目标变量和时间）
predictor_cols <- !names(target_vars) %in% c("LLB_D", "Time")
target_vars[, predictor_cols] <- scale(target_vars[, predictor_cols])  # 标准化

time_model <- lm(LLB_D ~ Time, data = target_vars)
target_vars$LLB_D_residuals <- residuals(time_model)
summary(time_model)

# Step 2: Prepare data for BRT model
predictors <- names(target_vars)[!names(target_vars) %in% c("LLB_D", "Time", "LLB_D_residuals")]
brt_data <- target_vars[, c("LLB_D_residuals", predictors)]
head(brt_data)

# Step 3: Split data into training and testing sets (70% training, 30% testing)
set.seed(123)
train_indices <- createDataPartition(brt_data$LLB_D_residuals, p = 0.7, list = FALSE)
training <- brt_data[train_indices, ]
testing <- brt_data[-train_indices, ]

# Step 4: Grid search for hyperparameter tuning
param_grid <- expand.grid(
  learning_rate = c(0.001, 0.005, 0.01, 0.05, 0.1),
  tree_complexity = c(1, 3, 5, 7, 9, 11),
  bag_fraction = c(0.1, 0.3, 0.5, 0.6, 0.7, 0.9, 1.1)
)

cv_results <- data.frame(
  learning_rate = numeric(),
  tree_complexity = numeric(),
  bag_fraction = numeric(),
  cv_deviance = numeric(),
  n_trees = numeric()
)

for (i in 1:nrow(param_grid)) {
  cat("Running model", i, "of", nrow(param_grid), "\n")
  
  lr <- param_grid$learning_rate[i]
  tc <- param_grid$tree_complexity[i]
  bf <- param_grid$bag_fraction[i]
  
  brt_model <- try(
    gbm.step(
      data = training,
      gbm.x = 2:ncol(training),
      gbm.y = 1,
      family = "gaussian",
      tree.complexity = tc,
      learning.rate = lr,
      bag.fraction = bf,
      silent = TRUE
    )
  )
  
  if (!inherits(brt_model, "try-error")) {
    cv_results <- rbind(cv_results, data.frame(
      learning_rate = lr,
      tree_complexity = tc,
      bag_fraction = bf,
      cv_deviance = brt_model$cv.statistics$deviance.mean,
      n_trees = brt_model$n.trees
    ))
  }
}


best_params <- cv_results[which.min(cv_results$cv_deviance), ]
print("Best model parameters:")
print(best_params)

# Step 5: Train the final model with the best parameters
final_model <- gbm.step(
  data = training,
  gbm.x = 2:ncol(training),
  gbm.y = 1,
  family = "gaussian",
  tree.complexity = best_params$tree_complexity,
  learning.rate = best_params$learning_rate,
  bag.fraction = best_params$bag_fraction
)

# Step 6: Evaluate the model on test data
# Make predictions
predictions <- predict.gbm(
  final_model,
  testing[, 2:ncol(testing)],
  n.trees = final_model$n.trees
)

# Calculate performance metrics
rmse <- sqrt(mean((predictions - testing$LLB_D_residuals)^2))
mae <- mean(abs(predictions - testing$LLB_D_residuals))
r_squared <- cor(predictions, testing$LLB_D_residuals)^2

# Print performance metrics
cat("Test RMSE:", rmse, "\n")
cat("Test MAE:", mae, "\n")
cat("Test R-squared:", r_squared, "\n")

# Step 7: Variable importance and visualization
# Variable importance
var_importance <- summary(final_model)
print(var_importance)

