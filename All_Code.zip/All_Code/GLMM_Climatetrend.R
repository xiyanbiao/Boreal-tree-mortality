print(getwd())
setwd("E:/papering/forest_mortality/样地数据统计/Trend_model")

library(Hmisc)
library(corrplot)
library(car)
library(caret)
library(lme4)
library(lmerTest) 
library(MuMIn)    
library(performance) 

# 读取数据并预处理
data <- read.csv("E:/papering/forest_mortality/样地数据统计/Trend_model/ClimateTrend_ST.csv", header = TRUE)
head(data)

#构建目标变量
target_vars <- data[, c("D_d","Year_d", "LSF",  "SCD_T", "MAT_T", "AGE", "BULK", "DEM", "SD")]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)

#随机效应
ECO_ID <- data[, c("ECO_ID")]
#计算残差
time_model <- lm(D_d ~ Year_d, data = target_vars)
target_vars$D_d_residuals <- residuals(time_model)
head(target_vars)

#剥离出自变量
predictors <- names(target_vars)[!names(target_vars) %in% c("D_d", "Year_d", "D_d_residuals")]

# 合并因变量自变量和随机变量
brt_data <- cbind(
  D_d_residuals = target_vars$D_d_residuals,
  D_d = target_vars$D_d,
  target_vars[, predictors],
  ECO_ID
)
brt_data$ECO_ID <- as.factor(brt_data$ECO_ID)
str(brt_data)

## ===== 对 fixed predictors 做标准化（scaled） =====

# 1. 定义固定效应变量（不含响应和随机效应）
fixed_predictors <- names(brt_data)[!names(brt_data) %in% c("D_d_residuals","D_d", "ECO_ID")]

# 2. 只对数值型的 fixed predictors 做缩放，避免因子/字符变量报错
num_vars <- fixed_predictors[sapply(brt_data[fixed_predictors], is.numeric)]

# 3. 标准化：减均值、除标准差
brt_data[num_vars] <- scale(brt_data[num_vars])

# 4. 再次检查 fixed_predictors（名称不变，数值已经 scaled）
fixed_predictors <- names(brt_data)[!names(brt_data) %in% c("D_d_residuals", "D_d", "ECO_ID")]

# 5. 构建模型公式
formula_string <- "D_d_residuals ~ "
formula_string <- paste(formula_string, paste(fixed_predictors, collapse = " + "))
formula_string <- paste(formula_string, " + (1 | ECO_ID) ")
model_formula <- as.formula(formula_string)
cat("Model Formula:\n")
print(model_formula)

# 6. 拟合线性混合效应模型
mixed_model <- lmer(model_formula, data = brt_data,
                    control = lmerControl(optimizer ="bobyqa"))

summary(mixed_model)
VarCorr(mixed_model)
model_performance(mixed_model)


