print(getwd())
setwd("E:/papering/forest_mortality/Environment/")

library(raster)
library(trend)  # 用于计算斜率

input_folder <- "E:/papering/forest_mortality/Environment/Vagetation/CA_all/NDWI/"  

# 获取所有.tif文件并按年份排序
tif_files <- list.files(input_folder, pattern = "NDWI_\\d{4}\\.tif$", full.names = TRUE)
tif_files <- sort(tif_files)  # 确保按时间顺序排列
print(tif_files)
# 提取年份（从 extreme_heat_days_YYYY.tif 格式中提取）
years <- as.numeric(gsub("NDWI_(\\d{4})\\.tif", "\\1", basename(tif_files)))

if (length(tif_files) > 0) {
  # 1. 计算平均值
  raster_stack <- stack(tif_files)
  mean_raster <- mean(raster_stack, na.rm = TRUE)
  
  # 2. 计算斜率（使用线性回归）
  # 创建一个函数计算每个像素的时间序列斜率
  calc_slope <- function(x) {
    if (all(is.na(x))) return(NA)
    tryCatch({
      # 使用Sen's斜率估计（更稳健的方法）
      mk.test <- mk.test(x)
      if (mk.test$p.value < 0.05) {  # 只有显著的趋势才计算斜率
        senslope <- sens.slope(x)
        return(senslope$estimates)
      } else {
        return(0)  # 不显著的趋势返回0
      }
    }, error = function(e) return(NA))
  }
  
  # 转换为矩阵进行计算（更高效）
  slope_raster <- calc(raster_stack, fun = function(x) {
    if (all(is.na(x))) return(NA)
    lm(x ~ years)$coefficients[2]  # 线性回归斜率
  })
  
  # 查看结果
  print("Mean values:")
  print(mean_raster)
  plot(mean_raster, main = "Mean Values")
  
  print("Slope values:")
  print(slope_raster)
  plot(slope_raster, main = "Slope Values (change per year)")
  
  # 保存结果
  writeRaster(mean_raster, "VOD_mean.tif", overwrite = TRUE)
  writeRaster(slope_raster, "VOD_slope.tif", overwrite = TRUE)
  
} else {
  message("没有找到TIFF文件")
}

