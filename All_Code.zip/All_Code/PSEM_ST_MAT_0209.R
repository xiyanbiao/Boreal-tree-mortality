print(getwd())
setwd("E:/papering/forest_mortality/样地数据统计/SEM_0201/")

library(piecewiseSEM)
#library(raster)
data <- read.csv("SEM_ST.csv", header=TRUE)     ## load csv file
head(data)

target_vars <- data[, c("D_d","Year_d", "AMG", names(data)[which(names(data) == "ALH"):which(names(data) == "NDWI_T")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)

# 标准化所有预测变量（不包括目标变量和时间）
scaled_vars <- !names(target_vars) %in% c("D_d","Year_d", "AMG")
target_vars[, scaled_vars] <- scale(target_vars[, scaled_vars])  # 标准化
head(target_vars)
# time_model <- lm(LDTM ~ Time, data = target_vars)
# target_vars$LDTM_residuals <- residuals(time_model)
# 
# predictors <- names(target_vars)[!names(target_vars) %in% c("LDTM", "Time", "LDTM_residuals")]
# total_data <- target_vars[, c("LDTM_residuals", predictors)]
# head(total_data)

######################---------初次假设------###################
pmodel <- psem(
  glm(SOS_T ~ EHD_T + LSF_T + MAT_T + MAP_T +
        EHD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(SIF_T ~ EHD_T + LSF_T + MAT_T + MAP_T +
        EHD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(VOD_T ~ EHD_T + LSF_T + MAT_T + MAP_T + 
        EHD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT + ALH + AGE + SD + SHA, family = "gaussian", target_vars), 
  glm(D_d ~ SOS_T + SIF_T + VOD_T +
        EHD_T + LSF_T + MAT_T + MAP_T + 
        EHD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars), data = target_vars)
######################--------结果总结--------################
summary(pmodel)

#####################-----模型评估和修改-----###############
basisSet(pmodel)
dSep(pmodel,conditioning=T)
fisherC(pmodel)
coef_list <- coefs(pmodel)  
write.csv(coef_list, "PSEM_AMG_ST_results.csv")

#######################------升级模型-------################
pmodel2 <- psem(
  glm(SOS_T ~ VPD_T + LSF_T + MAT_T + MAP_T +
        VPD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(SIF_T ~ VPD_T + LSF_T + MAT_T + MAP_T +
        VPD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(VOD_T ~ VPD_T + LSF_T + MAT_T + MAP_T + 
        VPD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT + ALH + AGE + SD + SHA, family = "gaussian", target_vars), 
  glm(D_d ~ SOS_T + SIF_T + VOD_T +
        VPD_T + LSF_T + MAT_T + MAP_T + 
        VPD + LSF + MAT + MAP +
        BULK + CEC + SAND + SOC + STN + DEM + 
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars), data = target_vars)
######################--------再次评估---------#############
summary(pmodel2)

basisSet(pmodel2)
dSep(pmodel2,conditioning=T)
fisherC(pmodel2)
summary(pmodel2)

coef_list <- coefs(pmodel2)  # From piecewiseSEM
write.csv(coef_list, "LDB_coefficients.csv")

# Capture the summary output
summary_output <- capture.output(summary(pmodel2))
# Write to a text file
writeLines(summary_output, "sem_summary_results.txt")

