print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig2/for_PSEM_1024/analysis")

library(piecewiseSEM)
#library(raster)
data <- read.csv("CA_ST_1029_forest.csv", header=TRUE)     ## load csv file
head(data)
target_vars <- data[, c("Dead_diffe","TIME", "LAT", names(data)[which(names(data) == "EHD"):which(names(data) == "SHA")])]
target_vars <- as.data.frame(lapply(target_vars, as.numeric))
head(target_vars)

# 标准化所有预测变量（不包括目标变量和时间）
scaled_vars <- !names(target_vars) %in% c("Dead_diffe", "TIME")
target_vars[, scaled_vars] <- scale(target_vars[, scaled_vars])  # 标准化
head(target_vars)
# time_model <- lm(LDTM ~ Time, data = target_vars)
# target_vars$LDTM_residuals <- residuals(time_model)
# 
# predictors <- names(target_vars)[!names(target_vars) %in% c("LDTM", "Time", "LDTM_residuals")]
# total_data <- target_vars[, c("LDTM_residuals", predictors)]
# head(total_data)

######################---------初次假设------###################
pmodel <- psem(
  glm(SOS_T ~ EHD_T + LSF_T + MAT_T + PRE_T +
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT + TIME + ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(SIF_T ~ EHD_T + LSF_T + MAT_T + PRE_T +
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT + TIME + ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(VOD_T ~ EHD_T + LSF_T + MAT_T + PRE_T + 
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT + TIME + ALH + AGE + SD + SHA, family = "gaussian", target_vars), 
  glm(Dead_diffe ~ SOS_T + SIF_T + VOD_T +
        EHD_T + LSF_T + MAT_T + PRE_T + 
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT + TIME + ALH + AGE + SD + SHA, family = "gaussian", target_vars), data = target_vars)
######################--------结果总结--------################
summary(pmodel)

#####################-----模型评估和修改-----###############
basisSet(pmodel)
dSep(pmodel,conditioning=T)
fisherC(pmodel)
coef_list <- coefs(pmodel)  
write.csv(coef_list, "PSEM_AMG_ST_results.csv")

#######################------升级模型-------################
pmodel2 <- psem(
  glm(SOS_T ~ EHD_T + LSF_T + MAT_T + PRE_T +
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(SIF_T ~ EHD_T + LSF_T + MAT_T + PRE_T +
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars),
  glm(VOD_T ~ EHD_T + LSF_T + MAT_T + PRE_T + 
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT +  ALH + AGE + SD + SHA, family = "gaussian", target_vars), 
  glm(Dead_diffe ~ SOS_T + SIF_T + VOD_T +
        EHD_T + LSF_T + MAT_T + PRE_T + 
        EHD + LSF + MAT + PRE +
        BULK + CEC + SAND + SOC + TN + DEM + Slope +
        LAT +  ALH + AGE + SD  +  SHA, family = "gaussian", target_vars), data = target_vars)
######################--------再次评估---------#############
summary(pmodel2)

basisSet(pmodel2)
dSep(pmodel2,conditioning=T)
fisherC(pmodel2)
summary(pmodel2)

coef_list <- coefs(pmodel2)  # From piecewiseSEM
write.csv(coef_list, "LDB_coefficients.csv")

# Capture the summary output
summary_output <- capture.output(summary(pmodel2))
# Write to a text file
writeLines(summary_output, "sem_summary_results.txt")

