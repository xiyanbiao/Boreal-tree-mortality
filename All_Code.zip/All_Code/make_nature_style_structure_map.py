# -*- coding: utf-8 -*-
"""
基于归一化后的三波段结构栅格，输出期刊风格空间分布图。

输入:
- Forest_Structure_RGB_2023_11_normalized.tif

输出:
- Forest_Structure_RGB_2023_11_nature_map.png
- Forest_Structure_RGB_2023_11_nature_map.pdf
"""

from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from osgeo import gdal
from pyproj import CRS
from shapely.geometry import box


BASE_DIR = Path(
    r"E:\papering\boreal forest structure\1StructurePattern\Raster\Mapping_structure\Sturcture_RGB"
)
RASTER_PATH = BASE_DIR / "Forest_Structure_RGB_2023_11_normalized.tif"
WORLD_PATH = Path(
    r"E:\papering\boreal forest structure\study_area\world_country\world_country.shp"
)
PNG_PATH = BASE_DIR / "Forest_Structure_RGB_2023_11_nature_map.png"
PDF_PATH = BASE_DIR / "Forest_Structure_RGB_2023_11_nature_map.pdf"


def read_downsampled_rgb(ds, max_width=2600):
    width = ds.RasterXSize
    height = ds.RasterYSize
    scale = min(1.0, max_width / width)
    buf_x = max(1, int(width * scale))
    buf_y = max(1, int(height * scale))

    bands = []
    nodata = ds.GetRasterBand(1).GetNoDataValue()
    for idx in range(1, 4):
        arr = ds.GetRasterBand(idx).ReadAsArray(
            buf_xsize=buf_x,
            buf_ysize=buf_y,
        ).astype(np.float32)
        bands.append(arr)

    rgb = np.dstack(bands)
    if nodata is None:
        valid = np.all(np.isfinite(rgb), axis=2)
    else:
        valid = np.all(np.isfinite(rgb) & (rgb != nodata), axis=2)
    return rgb, valid, nodata


def stretch_for_display(rgb, valid, gamma=0.95):
    display = np.zeros_like(rgb, dtype=np.float32)
    for i in range(3):
        band = rgb[:, :, i].astype(np.float64, copy=False)
        vals = band[valid]
        p2 = np.percentile(vals, 2)
        p98 = np.percentile(vals, 98)
        stretched = np.clip((band - p2) / (p98 - p2 + 1e-8), 0, 1)
        display[:, :, i] = (stretched ** gamma).astype(np.float32)
    return display


def raster_extent(ds):
    gt = ds.GetGeoTransform()
    width = ds.RasterXSize
    height = ds.RasterYSize
    xmin = gt[0]
    xmax = gt[0] + gt[1] * width
    ymax = gt[3]
    ymin = gt[3] + gt[5] * height
    return xmin, xmax, ymin, ymax


def valid_data_bounds(ds, valid):
    gt = ds.GetGeoTransform()
    height, width = valid.shape
    full_width = ds.RasterXSize
    full_height = ds.RasterYSize

    pixel_w = gt[1] * full_width / width
    pixel_h = gt[5] * full_height / height

    rows, cols = np.where(valid)
    row_min = rows.min()
    row_max = rows.max() + 1
    col_min = cols.min()
    col_max = cols.max() + 1

    xmin = gt[0] + col_min * pixel_w
    xmax = gt[0] + col_max * pixel_w
    ymax = gt[3] + row_min * pixel_h
    ymin = gt[3] + row_max * pixel_h
    return xmin, xmax, ymin, ymax


def add_scalebar(ax, xmin, xmax, ymin, ymax):
    width = xmax - xmin
    height = ymax - ymin
    bar_len = 1_000_000
    x0 = xmin + 0.06 * width
    y0 = ymin + 0.07 * height

    ax.plot([x0, x0 + bar_len], [y0, y0], color="#1f1f1f", lw=2.0, solid_capstyle="butt")
    ax.plot([x0, x0], [y0 - 0.012 * height, y0 + 0.012 * height], color="#1f1f1f", lw=1.4)
    ax.plot(
        [x0 + bar_len, x0 + bar_len],
        [y0 - 0.012 * height, y0 + 0.012 * height],
        color="#1f1f1f",
        lw=1.4,
    )
    ax.text(
        x0 + bar_len / 2,
        y0 + 0.025 * height,
        "1000 km",
        ha="center",
        va="bottom",
        fontsize=8.5,
        color="#1f1f1f",
    )


def add_channel_note(ax, xmin, xmax, ymin, ymax):
    width = xmax - xmin
    height = ymax - ymin
    x0 = xmin + 0.03 * width
    y0 = ymax - 0.06 * height

    ax.text(
        x0,
        y0,
        "Pan-boreal forest structure, 2023",
        ha="left",
        va="top",
        fontsize=11,
        fontweight="bold",
        color="#1f1f1f",
        bbox=dict(boxstyle="round,pad=0.35", facecolor=(1, 1, 1, 0.9), edgecolor="none"),
    )
    ax.text(
        x0,
        y0 - 0.045 * height,
        "RGB channels:",
        ha="left",
        va="top",
        fontsize=8.5,
        color="#3a3a3a",
    )
    ax.text(x0 + 0.12 * width, y0 - 0.045 * height, "R LAD", ha="left", va="top", fontsize=8.5, color="#c23b3b")
    ax.text(x0 + 0.22 * width, y0 - 0.045 * height, "G VCI", ha="left", va="top", fontsize=8.5, color="#2d8a4f")
    ax.text(x0 + 0.32 * width, y0 - 0.045 * height, "B CRR", ha="left", va="top", fontsize=8.5, color="#2f6db3")


def main():
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "axes.linewidth": 0.8,
            "savefig.bbox": "tight",
            "figure.facecolor": "white",
            "axes.facecolor": "#f7f5f1",
        }
    )

    gdal.UseExceptions()
    ds = gdal.Open(str(RASTER_PATH))
    if ds is None:
        raise FileNotFoundError(f"无法打开栅格: {RASTER_PATH}")

    rgb, valid, _ = read_downsampled_rgb(ds)
    display_rgb = stretch_for_display(rgb, valid)
    alpha = np.where(valid, 1.0, 0.0)

    raster_crs = CRS.from_wkt(ds.GetProjection())
    full_extent = raster_extent(ds)
    data_bounds = valid_data_bounds(ds, valid)
    pad = 250_000
    xmin, xmax, ymin, ymax = (
        data_bounds[0] - pad,
        data_bounds[1] + pad,
        data_bounds[2] - pad,
        data_bounds[3] + pad,
    )

    world = gpd.read_file(WORLD_PATH).to_crs(raster_crs)
    world = world[world.geometry.notnull()].copy()
    world = world[np.isfinite(world.geometry.bounds).all(axis=1)].copy()
    clip_box = box(xmin, ymin, xmax, ymax)
    world = world[world.geometry.intersects(clip_box)].copy()
    world = world[world.is_valid].copy()
    world["geometry"] = world.geometry.simplify(15_000, preserve_topology=True)

    fig, ax = plt.subplots(figsize=(8.6, 5.4), dpi=600)

    world.plot(ax=ax, color="#eee8df", edgecolor="#b7afa3", linewidth=0.28, zorder=1)
    ax.imshow(
        display_rgb,
        extent=[full_extent[0], full_extent[1], full_extent[2], full_extent[3]],
        origin="upper",
        interpolation="nearest",
        alpha=alpha,
        zorder=2,
    )
    world.boundary.plot(ax=ax, color="#6f685e", linewidth=0.18, zorder=3)

    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.8)
        spine.set_edgecolor("#3c3c3c")

    add_scalebar(ax, xmin, xmax, ymin, ymax)
    add_channel_note(ax, xmin, xmax, ymin, ymax)

    ax.text(
        xmax - 0.01 * (xmax - xmin),
        ymin + 0.02 * (ymax - ymin),
        "Display stretch based on normalized RGB composite",
        ha="right",
        va="bottom",
        fontsize=7.5,
        color="#5a5a5a",
    )

    fig.savefig(PNG_PATH, dpi=600, facecolor="white")
    fig.savefig(PDF_PATH, dpi=600, facecolor="white")
    plt.close(fig)

    print(f"png={PNG_PATH}")
    print(f"pdf={PDF_PATH}")


if __name__ == "__main__":
    main()
