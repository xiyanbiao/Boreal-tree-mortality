# -*- coding: utf-8 -*-
"""
拼接 CH 文件夹中的所有 tif，输出为单个 GeoTIFF。
"""

from pathlib import Path
import glob

import rasterio
from rasterio.merge import merge


INPUT_DIR = Path(r"E:\papering\boreal forest structure\1StructurePattern\Raster\CH")
OUTPUT_PATH = Path(r"E:\papering\boreal forest structure\1StructurePattern\Raster\CH_CA.tif")


def main():
    raster_files = sorted(glob.glob(str(INPUT_DIR / "*.tif")))
    if not raster_files:
        raise FileNotFoundError(f"未找到 tif 文件: {INPUT_DIR}")

    print(f"找到 {len(raster_files)} 个栅格，开始拼接...")

    src_files = [rasterio.open(fp) for fp in raster_files]
    try:
        mosaic, out_transform = merge(src_files)

        out_meta = src_files[0].meta.copy()
        out_meta.update(
            {
                "driver": "GTiff",
                "height": mosaic.shape[1],
                "width": mosaic.shape[2],
                "transform": out_transform,
                "compress": "lzw",
            }
        )

        with rasterio.open(OUTPUT_PATH, "w", **out_meta) as dest:
            dest.write(mosaic)

    finally:
        for src in src_files:
            src.close()

    print(f"输出完成: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
