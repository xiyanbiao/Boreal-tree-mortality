print(getwd())
setwd("E:/papering/forest_mortality/Plot/fig3/small_tree/20260210_ST")
library(ggplot2)
library(scales)  # 用于比例变换
library(ggdist)
library(ggdensity)

data <- read.csv("ST_ML_0210.csv")
head(data)

# Fit a model (linear or more complex if needed)
model <- lm(STML_original ~ STML_residual, data=data)
summary(model)

# Function to convert any LSF_partial value to original_LSF
convert_to_original <- function(partial_value) {
  predict(model, newdata=data.frame(STML_residual=partial_value))
}
# Add predicted original_LSF values to the dataframe
data$STML_predicted <- predict(model, newdata=data)

# If you want to check some of the predictions
head(data[, c("STML_original", "STML_residual", "STML_predicted")])

# Export the updated dataframe to CSV
write.csv(data, "STML_predictions.csv", row.names=FALSE)

###################################################################

data <- read.csv("ST_MG_0210.csv")
head(data)

# Fit a model (linear or more complex if needed)
model <- lm(STMG_original ~ STML_residual, data=data)
summary(model)

# Function to convert any LSF_partial value to original_LSF
convert_to_original <- function(partial_value) {
  predict(model, newdata=data.frame(STML_residual=partial_value))
}
# Add predicted original_LSF values to the dataframe
data$STMG_predicted <- predict(model, newdata=data)

# If you want to check some of the predictions
head(data[, c("STML_residual", "STMG_original", "STMG_predicted")])

# Export the updated dataframe to CSV
write.csv(data, "STMG_predictions.csv", row.names=FALSE)

###################################################################

data <- read.csv("STMG_predictions.csv")
head(data)

# Fit a model (linear or more complex if needed)
model <- lm(MAT_original ~ MAT_residual, data=data)
summary(model)

# Function to convert any LSF_partial value to original_LSF
convert_to_original <- function(partial_value) {
  predict(model, newdata=data.frame(MAT_residual=partial_value))
}
# Add predicted original_LSF values to the dataframe
data$MAT_predicted <- predict(model, newdata=data)

# If you want to check some of the predictions
head(data[, c("MAT_original", "MAT_residual", "MAT_predicted")])

# Export the updated dataframe to CSV
write.csv(data, "ST_MAT_total.csv", row.names=FALSE)



# data <- read.csv("Live_Dead_LT_MAT_with_predictions.csv")
# head(data)
# 
# # Fit a model (linear or more complex if needed)
# model <- lm(MAT_data ~ MAT_partial2, data=data)
# summary(model)
# 
# # Function to convert any LSF_partial value to original_LSF
# convert_to_original <- function(partial_value) {
#   predict(model, newdata=data.frame(MAT_partial2=partial_value))
# }
# # Add predicted original_LSF values to the dataframe
# data$MAT_predicted2 <- predict(model, newdata=data)
# 
# # If you want to check some of the predictions
# head(data[, c("MAT_partial2", "MAT_data", "MAT_predicted2")])
# 
# # Export the updated dataframe to CSV
# write.csv(data, "Live_Dead_LT_MAT_with_predictions2.csv", row.names=FALSE)
